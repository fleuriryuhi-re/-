# Windows サウンド設定ツール 概要資料

## 1. 目的
Windows の再生/録音デバイス設定を手動運用から半自動化し、業務利用時の切替ミスを減らすことを目的とした WinForms ツールです。

## 2. 対象ソース
- 本番版: AudioSetupUI.cs
- 開発版: AudioSetupUI_dev.cs
- 配置先: tools/windows-audio/latest-source

## 3. 主要機能
- 自動設定
  - 本番版: Plantronics DA80 と Voicemeeter を規定のロールに再設定
  - 開発版: Realtek と Voicemeeter を規定のロールに再設定
- Voicemeeter 自動起動
  - 自動設定完了時、完了ダイアログ表示中に Voicemeeter x64 の起動処理を実行
  - 既に起動済みの場合は重複起動せず、ログで状態を通知
- デバイス一覧更新
  - 再生/録音の状態と既定デバイスを再取得
  - 全デバイス無効時は警告し、サウンド設定画面を開く導線を表示
- サウンド設定を開く
  - control.exe mmsys.cpl を起動
- Voicemeeter アンインストール
  - 確認後、Voicemeeter 停止を試行
  - 優先候補: Program Files (x86) の voicemeeterprosetup.exe / voicemeetersetup.exe
  - フォールバック: Program Files 側 setup、uninstall.exe、unins000.exe、レジストリの UninstallString
  - 起動できない場合は appwiz.cpl を開く導線を表示
- 通常業務復帰
  - Voicemeeter 停止、仮想デバイス無効化、業務用デバイスを既定/通信に再設定
- 終了時保護
  - Voicemeeter 起動中に閉じる操作を行うと確認ダイアログを表示

## 4. 画面構成
- 操作ボタン
  - 自動設定を実行
  - デバイス一覧を更新
  - サウンド設定を開く
  - Voicemeeterをアンインストール
  - 通常業務用へ戻す（開発版は文言差分あり）
- 表示領域
  - 既定デバイス状態ラベル
  - 再生デバイス一覧
  - 録音デバイス一覧
  - 実行ログ

## 5. 期待される運用フロー
1. アプリ起動
2. デバイス一覧更新で現状確認
3. 利用モードに応じて 自動設定 または 通常業務復帰 を実行
4. 必要に応じて Voicemeeter アンインストールを実行
5. 終了時の確認ダイアログに従って終了

## 6. 依存条件
- Windows
- 対象オーディオデバイス（本番: DA80、開発: Realtek/Intel SST、Voicemeeter）
- 管理者昇格（アンインストーラー起動時）

## 7. テスト資料
動作検証テスト項目は次のファイルを使用します。
- WindowsAudioTool_TestCases.csv

Excel で開き、実施結果と証跡列を記入してください。

## 8. 既知の注意点
- デバイス名差分や接続状態により、候補解決ロジックがフォールバックを実行する場合があります。
- Voicemeeter 未インストール時は、自動設定とアンインストール機能で案内メッセージが表示されます。
- レジストリ/実行ファイル探索結果に依存するため、インストール形態によって起動順序が変わる場合があります。
